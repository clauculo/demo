<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/api/v1/users' => [[['_route' => 'users.create', '_controller' => 'App\\Controller\\UserController::createUser'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/api/v(?'
                    .'|1/users/([^/]++)(*:67)'
                    .'|2/users/([^/]++)(*:90)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        67 => [[['_route' => 'users.get', '_controller' => 'App\\Controller\\UserController::getUser'], ['id'], ['GET' => 0], null, false, true, null]],
        90 => [
            [['_route' => 'users.get_new', '_controller' => 'App\\Controller\\UserNewController::getUser'], ['user'], ['GET' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
